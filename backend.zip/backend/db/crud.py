# Importaciones para operaciones de base de datos
from sqlalchemy.orm import Session
from backend.db.models import User
import uuid
from sqlalchemy import text

# ========== FUNCIONES DE USUARIOS ==========

def get_user_by_email(db: Session, email: str) -> User | None:
    # Buscar usuario por su email en la base de datos
    return db.query(User).filter(User.email == email).first()

def get_user_by_id(db: Session, user_id: str) -> User | None:
    # Validar que el user_id es un UUID válido
    try:
        uid = uuid.UUID(user_id)
    except Exception:
        return None
    # Buscar usuario por su ID
    return db.query(User).filter(User.user_id == uid).first()

def create_user(db: Session, email: str, password_hash: str, full_name: str | None):
    # Crear nuevo usuario con los datos proporcionados
    user = User(user_id=uuid.uuid4(), email=email, password_hash=password_hash, full_name=full_name)
    # Agregar usuario a la sesión
    db.add(user)
    # Confirmar cambios en la base de datos
    db.commit()
    # Refrescar objeto user con datos de la BD
    db.refresh(user)
    # Retornar el usuario creado
    return user

def create_refresh_session(db: Session, user_id: str, refresh_token_hash: str, expires_at):
    # Crear nueva sesión de refresco para el usuario
    db.execute(
        text("""INSERT INTO sessions(session_id, user_id, refresh_token_hash, expires_at)
                VALUES (:sid, :uid, :rth, :exp)"""),
        {
            "sid": str(uuid.uuid4()),
            "uid": user_id,
            "rth": refresh_token_hash,
            "exp": expires_at
        },
    )
    # Confirmar la inserción
    db.commit()

# ========== FUNCIONES DE BODEGAS Y ROLES (SQL puro para velocidad) ==========

import uuid

def create_cellar(db: Session, name: str) -> str:
    # Insertar nueva bodega en la base de datos y retornar su ID
    row = db.execute(
        text("INSERT INTO cellars(cellar_id, name) VALUES (:cid, :n) RETURNING cellar_id"),
        {
            "cid": str(uuid.uuid4()),
            "n": name
        }
    ).fetchone()

    # Confirmar la inserción
    db.commit()
    # Retornar el ID de la bodega creada
    return str(row[0])


def add_member(db: Session, cellar_id: str, user_id: str, role: str):
    # Agregar o actualizar miembro en una bodega
    db.execute(text("INSERT INTO cellar_members(cellar_id, user_id, role) VALUES (:c, :u, :r) ON CONFLICT (cellar_id, user_id) DO UPDATE SET role = EXCLUDED.role"),
               {"c": cellar_id, "u": user_id, "r": role})
    # Confirmar los cambios
    db.commit()

def list_my_cellars(db: Session, user_id: str):
    # Obtener todas las bodegas del usuario con su rol en cada una
    rows = db.execute(text("""SELECT c.cellar_id, c.name, cm.role
                             FROM cellars c
                             JOIN cellar_members cm ON cm.cellar_id = c.cellar_id
                             WHERE cm.user_id = :u
                             ORDER BY c.created_at DESC"""), {"u": user_id}).fetchall()
    # Convertir resultados a lista de diccionarios
    return [{"cellar_id": str(r[0]), "name": r[1], "role": r[2]} for r in rows]

def get_user_role_in_cellar(db: Session, cellar_id: str, user_id: str):
    # Obtener el rol de un usuario en una bodega específica
    row = db.execute(text("SELECT role FROM cellar_members WHERE cellar_id = :c AND user_id = :u"), {"c": cellar_id, "u": user_id}).fetchone()
    # Retornar el rol o None si el usuario no es miembro
    return row[0] if row else None

def list_members(db: Session, cellar_id: str):
    # Obtener lista de todos los miembros de una bodega
    rows = db.execute(text("""SELECT u.user_id, u.email, u.full_name, cm.role, cm.created_at
                             FROM cellar_members cm
                             JOIN users u ON u.user_id = cm.user_id
                             WHERE cm.cellar_id = :c
                             ORDER BY cm.created_at"""), {"c": cellar_id}).fetchall()
    # Convertir resultados a lista de diccionarios con datos formateados
    return [{"user_id": str(r[0]), "email": r[1], "full_name": r[2], "role": r[3], "created_at": r[4].isoformat()} for r in rows]

def set_member_role(db: Session, cellar_id: str, user_id: str, role: str):
    # Actualizar el rol de un miembro en una bodega
    db.execute(text("UPDATE cellar_members SET role = :r WHERE cellar_id = :c AND user_id = :u"), {"r": role, "c": cellar_id, "u": user_id})
    # Confirmar los cambios
    db.commit()

def remove_member(db: Session, cellar_id: str, user_id: str):
    # Eliminar un miembro de una bodega
    db.execute(text("DELETE FROM cellar_members WHERE cellar_id = :c AND user_id = :u"), {"c": cellar_id, "u": user_id})
    # Confirmar la eliminación
    db.commit()
