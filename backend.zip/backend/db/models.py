# Importaciones para definir modelos SQLAlchemy
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String, Text, DateTime, func, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
import uuid

# Clase base para todos los modelos SQLAlchemy
class Base(DeclarativeBase):
    pass

# Modelo para la tabla de usuarios
class User(Base):
    __tablename__ = "users"
    # ID único en formato UUID
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True)
    # Email del usuario (único y obligatorio)
    email: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    # Hash bcrypt de la contraseña (obligatorio)
    password_hash: Mapped[str] = mapped_column(Text, nullable=False)
    # Nombre completo del usuario (opcional)
    full_name: Mapped[str | None] = mapped_column(String, nullable=True)
    # Fecha de creación (se establece automáticamente)
    created_at: Mapped[DateTime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)


# Modelo para la tabla de sesiones de refresco de tokens
class Session(Base):
    __tablename__ = "sessions"
    # ID único de la sesión
    session_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    # ID del usuario propietario de la sesión (clave foránea)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.user_id"))
    # Hash bcrypt del token de refresco (para validar el token)
    refresh_token_hash: Mapped[str] = mapped_column(String, nullable=False)
    # Fecha y hora de expiración de la sesión
    expires_at: Mapped[DateTime] = mapped_column(DateTime(timezone=True), nullable=False)


